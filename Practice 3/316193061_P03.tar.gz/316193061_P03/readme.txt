Villavicencio Cárdenas Ulrich
316193061

Si intentan copiar del pdf la función: tooLong ["Hola", "HolaH", "HolaHo", "HolaHol", “HolaHola”]
no funciona correctamente, tendrán que escribirla manualmente.

Lo mismo sucede con: quitaElemento [’a’,’a’,’a’,’a’,’a’,’a’] ’a’.
